
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  serverUrl = 'https://localhost:7068/';
  errorData: {};
  userDetails: any = {};
  constructor(private http: HttpClient, private router: Router, public messageService: MessageService) { }

  redirectUrl: string;

  login(username: string, password: string) {
    return this.http.post<any>(`${this.serverUrl}Auth/login`, { username: username, password: password });
  }

  signUp(payLoad) {
    return this.http.post<any>(`${this.serverUrl}User`, payLoad);
  }
  addAddressLocation(payLoad) {
    return this.http.post<any>(`${this.serverUrl}DeliveryLocation`, payLoad);
  }

  isLoggedIn() {
    if (localStorage.getItem('currentUser')) {
      return true;
    }
    return false;
  }

  getAuthorizationToken() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    return currentUser.token;
  }

  logout() {
    localStorage.removeItem('currentUser');
    this.router.navigate(['/auth/login']);
  }

  getUserDetailsByID() {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("id", this.userDetails.userID);
    const authToken = this.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });

    return this.http.get<any>(`${this.serverUrl}User`, { params: queryParams, headers: headers });
  }
  getUserDeleveryDetailsByID() {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("UserID", this.userDetails.userID);
    const authToken = this.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });

    return this.http.get<any>(`${this.serverUrl}DeliveryLocation/GetDeliveryLocation`, { params: queryParams, headers: headers });
  }

  handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {

      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {

      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }

    // return an observable with a user-facing error message
    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.',
      message: error.error
    };
    return throwError(this.errorData);
  }
}

import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from 'src/app/services/auth/auth.service';
import { CartItem } from '../model/cartItem';



@Injectable({
  providedIn: 'root'
})
export class OrderManagementService {
  private totalItems: BehaviorSubject<number> = new BehaviorSubject<number>(0);

  isCartAvailable: boolean = false;

  cartDetails: any = {};

  cartItems: CartItem[] = [];

  orderDetails:any = {};
  constructor(private http: HttpClient, public authService: AuthService) { }

  //function for set headers with token
  getHeaders() {
    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });

    const requestOptions = { headers: headers };
    return requestOptions;
  }

// function for get the totalAmount of cartList
  getTotalValue(): number {
    let sum = this.cartItems.reduce(
      (a, b) => { a = a + b.item?.price * b.quantity; return a; }, 0);
    return sum;
  }

// function for get all the products/items
  getProducts() {
    return this.http.get<any>(`${this.authService.serverUrl}Items`, this.getHeaders());
  }

  // function for get the itemdetils by item id
  getItem(id) {
    return this.http.get<any>(`${this.authService.serverUrl}Items/${id}`, this.getHeaders());
  }

  //function for getCartList
  getCartList(userId) {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("UserId", userId);

    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });

    return this.http.get<any>(`${this.authService.serverUrl}Cart/GetcartAsync`, { params: queryParams, headers: headers });
  }

   //function for getCartSubItems
  getCartSubItems() {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("CartId", this.cartDetails.cartID);

    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });

    return this.http.get<any>(`${this.authService.serverUrl}GetOrderListItemsAsync`, { params: queryParams, headers: headers });
  }

  // function for create new cart
  addItemToCart(payLoad) {
    return this.http.post<any>(`${this.authService.serverUrl}Cart`, payLoad, this.getHeaders());
  }
  //function for add subitems to cart
  addSubItemToCartByCartID(payLoad) {
    return this.http.post<any>(`${this.authService.serverUrl}AddCartSubItemsAsync`, payLoad, this.getHeaders());
  }

  //function for updateCartItem
  updateCartItem(itemId, payLoad) {

    let queryParams = new HttpParams();
    queryParams = queryParams.append("CartId", this.cartDetails.cartID);
    queryParams = queryParams.append("ItID", itemId);

    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });
    return this.http.put<any>(`${this.authService.serverUrl}UpdateCartSubItemsAsync`, payLoad, { params: queryParams, headers: headers });
  }

  //function for check item exist in cart or not
  checkItemInCart(itemID) {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("CartId", this.cartDetails.cartID);
    queryParams = queryParams.append("ItID", itemID);

    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });

    return this.http.get<any>(`${this.authService.serverUrl}GetCartSubItemsAsync`, { params: queryParams, headers: headers });
  }

  //function update cart master amount
  updateMasterCart(payLoad) {
    return this.http.put<any>(`${this.authService.serverUrl}Cart/${this.cartDetails.cartID}`, payLoad, this.getHeaders());
  }

// function for get items in the cart
  getCartItemsList() {
    if (this.authService.userDetails && this.authService.userDetails.userID) {
      this.getCartList(this.authService.userDetails.userID).subscribe((data) => {
        if (data && data.data !== null) {
          this.isCartAvailable = true;
          this.cartDetails = data.data;
          this.getSubItems();
        } else {
          this.isCartAvailable = false;
           this.cartItems = [];
        }
      },
        (error) => {
          console.log("error", error);
        }
      );
    }

  }

  //function for get the subitem in the cart
  getSubItems() {
    this.cartItems = [];
    this.getCartSubItems().subscribe((cartList) => {
      cartList.data.forEach(item => {
      const cartItemObject: CartItem = new CartItem();

      cartItemObject.item.id = item.itID;
      cartItemObject.item.itemName = item.itName;
      cartItemObject.item.image = item.image;
      cartItemObject.item.price = item.rate;
      cartItemObject.item.amount = item.amount;
      cartItemObject.quantity = item.qty;
      this.cartItems.push(cartItemObject);        
      });      
    });

  }

  //function for remove the items in the cart

  removeCartItem(itemId) {


    let queryParams = new HttpParams();
    queryParams = queryParams.append("CartId", this.cartDetails.cartID);
    queryParams = queryParams.append("ItID", itemId);

    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });
    return this.http.delete<any>(`${this.authService.serverUrl}DeleteRegionAsync`, { params: queryParams, headers: headers });
  }

  //function for get all time order list by user id
  getAllOrderList() {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("UserId", this.authService.userDetails.userID);
    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });
    return this.http.get<any>(`${this.authService.serverUrl}Cart/GetAllOrderListAsync`, { params: queryParams, headers: headers });
  }

  //function for get all particular ordered items  by cart id
  
  getOrderedItemsList(CartId) {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("CartId", CartId);
    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });
    return this.http.get<any>(`${this.authService.serverUrl}GetOrderListItemsAsync`, { params: queryParams, headers: headers });
  }

  //function for get particular order details  by Cart id
  
  getOrderDetails(CartId) {
    let queryParams = new HttpParams();
    queryParams = queryParams.append("CartId", CartId);
    const authToken = this.authService.getAuthorizationToken();
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`
    });
    return this.http.get<any>(`${this.authService.serverUrl}Cart/GetcartMasterAsync`, { params: queryParams, headers: headers });
  }
  


}


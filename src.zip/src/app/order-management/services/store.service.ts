import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';
import { AuthService } from 'src/app/services/auth/auth.service';
import { OrderManagementService } from './order-management.service';


@Injectable({
  providedIn: 'root'
})
export class StoreService {

  constructor(public orderManagementService: OrderManagementService,public authService: AuthService,public messageService: MessageService) { }

    //function for add the item to cart
    addToCart(selectedItem): void {

      let cartItem = { item: selectedItem, quantity: 1 }
  
      this.orderManagementService.cartItems.push(cartItem);
  
      let cartObj = {
        "grossAmount": this.orderManagementService.getTotalValue(),
        "userId": this.authService.userDetails.userID
      }
  
  
      if (this.orderManagementService.isCartAvailable == false) {
        this.orderManagementService.addItemToCart(cartObj).subscribe((data) => {
          if (data.cartID !== null && data.cartID !== undefined) {
            this.addSubItemsToCart(data.cartID, cartItem);
          }
        },
        (error) => {
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
          console.log("error", error);
        });
      } else {
        this.addSubItemsToCart(this.orderManagementService.cartDetails.cartID, cartItem);
      }
    }

    //function for add subitems in cart
    addSubItemsToCart(cartID, cartItem) {
      
      let subItemObj = {
        "cartId": cartID,
        "qty": cartItem.quantity,
        "rate": cartItem.item.price,
        "amount": (cartItem.item.price * cartItem.quantity),
        "itID": cartItem.item.id,
        "itName": cartItem.item.itemName,
        "image": cartItem.item.image
      }
      this.orderManagementService.addSubItemToCartByCartID(subItemObj).subscribe((data) => {
        if (this.orderManagementService.isCartAvailable == false) {
          this.messageService.add({ severity: 'success', summary: 'Success', detail: cartItem.item.itemName + " " + "added to cart" });
        } else {
          let grossAmount = this.orderManagementService.getTotalValue();
          this.updateMasterCartAmount(grossAmount);
        }
      },
      (error) => {
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
        console.log("error", error);
      });
    }

    // function for check item exist in the cart
    checkCartItemById(item) {
      if (this.orderManagementService.isCartAvailable == false) {
        this.addToCart(item);
      } else {
        this.orderManagementService.checkItemInCart(item.id).subscribe((response) => {
          
          if (response.data && response.data !== null) {
            this.updateItemQuantity(response.data);
          } else {            
            let cartItem = { item: item, quantity: 1 }  
            this.orderManagementService.cartItems.push(cartItem);
            this.addSubItemsToCart(this.orderManagementService.cartDetails.cartID,cartItem);
          }
        },
        (error) => {
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
          console.log("error", error);
        });
      }
  
    }

    //function for update quantity by item
    updateItemQuantity(item) {
      
      let quantity = (item.qty + 1);
      let grossAmount = (this.orderManagementService.cartDetails.grossAmount + item.rate);
  
      let payLoad = {
        "qty": quantity,
        "amount": (item.rate * quantity)
      }
      this.orderManagementService.updateCartItem(item.itID, payLoad).subscribe((response) => {
        this.updateMasterCartAmount(grossAmount);
      },
      (error) => {
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
        console.log("error", error);
      })
    }
    //function for update master cart deatils
    updateMasterCartAmount(totalAmount) {
      
      let payLoad = {
        "grossAmount": totalAmount,
        "statusId": 1
      }
      this.orderManagementService.updateMasterCart(payLoad).subscribe((response) => {
        this.messageService.add({ severity: 'success', summary: 'Success', detail: "Cart updated to cart" });
        this.orderManagementService.getCartItemsList();
      },
      (error) => {
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
        console.log("error", error);
      })
    }

}

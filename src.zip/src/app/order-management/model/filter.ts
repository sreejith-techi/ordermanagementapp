export interface Filter{
    name: string;
    categories:string[];
}
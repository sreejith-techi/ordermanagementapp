export interface Item{
    id: number;
    itemName: string;
    itemCode: string;
    price: number;
    category: string;
    description?: string;
    image?: string;
    rating?: number;
    amount?:number;
}
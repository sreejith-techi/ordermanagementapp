import { Item } from "./item";

export class CartItem {
    public item: Item = {
        id: 0, itemName: "", price: 0, category: "", description: "",
        itemCode: ""
    };
    public quantity: number = 0;
}
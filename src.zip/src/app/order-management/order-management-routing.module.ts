import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { ItemViewComponent } from './components/item-view/item-view.component';
import { OrderListComponent } from './components/order-list/order-list.component';
import { OrderViewComponent } from './components/order-view/order-view.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { ViewCartComponent } from './components/view-cart/view-cart.component';


const routes: Routes = [
  {
    path: '', component: HomeComponent,
  },
  {
    path: 'home', component: HomeComponent
  },
  {
    path: 'order-list', component: OrderListComponent
  },
  {
    path: 'view-order/:id', component: OrderViewComponent
  },
  {
    path: 'view-item/:id', component: ItemViewComponent
  },
  {
    path: 'view-cart', component: ViewCartComponent
  },
  {
    path: 'user-profile', component: UserProfileComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderManagementRoutingModule { }

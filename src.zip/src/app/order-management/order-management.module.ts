import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderManagementRoutingModule } from './order-management-routing.module';
import { HomeComponent } from './components/home/home.component';
import { OrderListComponent } from './components/order-list/order-list.component';
import { OrderViewComponent } from './components/order-view/order-view.component';
import { SharedModule } from '../shared/shared.module';
import { ItemViewComponent } from './components/item-view/item-view.component';
import { ViewCartComponent } from './components/view-cart/view-cart.component';
import { StoreService } from './services/store.service';
import { OrderManagementService } from './services/order-management.service';
import { UserProfileComponent } from './components/user-profile/user-profile.component';



@NgModule({
  declarations: [
    HomeComponent,
   OrderListComponent,
   OrderViewComponent,
   ItemViewComponent,
   ViewCartComponent,
   UserProfileComponent
  ],
  imports: [
    CommonModule,
    OrderManagementRoutingModule,
    SharedModule
  ],
  providers:[StoreService,OrderManagementService]
})
export class OrderManagementModule { }

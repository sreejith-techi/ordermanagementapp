import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderManagementService } from '../../services/order-management.service';
import { StoreService } from '../../services/store.service';

@Component({
    selector: 'app-item-view',
    templateUrl: './item-view.component.html',
    styleUrls: ['./item-view.component.scss']
})
export class ItemViewComponent implements OnInit {

    itemData: any = {}
    constructor(private orderService: OrderManagementService, private route: ActivatedRoute, private router: Router,public storeService: StoreService) {
    }

    ngOnInit() {
        this.fetchItemById();
    }

    //function fetch the particular item details by item id
    fetchItemById() {
        const id = Number(this.route.snapshot.paramMap.get('id'));
        this.orderService.getItem(id).subscribe((response) =>{
            if(response.data && response.data !== null){
                this.itemData = response.data;
            }
        });
    }

}

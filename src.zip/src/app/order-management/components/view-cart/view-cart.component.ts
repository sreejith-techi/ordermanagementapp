import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { OrderManagementService } from '../../services/order-management.service';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.scss']
})
export class ViewCartComponent implements OnInit {

  isSpinner: boolean = false;
  constructor(public orderManagementService: OrderManagementService, public messageService: MessageService, public storeService: StoreService) { }

  ngOnInit(): void {
    this.orderManagementService.getCartItemsList();
  }

  // function for remove the item from the cart list
  removeItemFromCart(item) {

    let totalAmount = ((this.orderManagementService.cartDetails.grossAmount) - (item.item.price * item.quantity))
    this.orderManagementService.removeCartItem(item.item.id).subscribe((response) => {
      if (response.data && response.data !== null) {
       this.updateMasterCartAmount(totalAmount);
      }
    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    })
  }

  // function for updating the master cart amount

  updateMasterCartAmount(totalAmount) {

    let payLoad = {
      "grossAmount": totalAmount,
      "statusId": 1
    }

    this.orderManagementService.updateMasterCart(payLoad).subscribe((response) => {
      this.messageService.add({ severity: 'success', summary: 'Success', detail: "Item Removed from cart" });
      this.orderManagementService.getCartItemsList();

    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    })
  }

  // function for place order
  placeOrderItems() {
    let payLoad = {
      "grossAmount": this.orderManagementService.getTotalValue(),
      "statusId": 2
    }

    this.orderManagementService.updateMasterCart(payLoad).subscribe((response) => {
      if (response.data && response.data.statusId == 2) {
        this.orderManagementService.isCartAvailable = false;
        this.orderManagementService.getCartItemsList();
        this.messageService.add({ severity: 'success', summary: 'Success', detail: "Order Placed Successfully" });
      }
    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    })
  }

  // function for remove all items from the cart list
  removeAllItemsFromCart() {
    this.orderManagementService.cartItems.forEach((cartItem) => {
        this.removeItemFromCart(cartItem);
    });
  } 

  // function for updating the curt cart item item quantity and amount
  changeItemQuantity(event, item) {

    let quantity = event.value;
    let grossAmount = this.orderManagementService.getTotalValue();

    let payLoad = {
      "qty": quantity,
      "amount": (item.item.price * quantity)
    }

    this.orderManagementService.updateCartItem(item.item.id, payLoad).subscribe((response) => {
      this.storeService.updateMasterCartAmount(grossAmount);
    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    })
  }

}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MessageService } from 'primeng/api';
import { OrderManagementService } from '../../services/order-management.service';

@Component({
  selector: 'app-order-view',
  templateUrl: './order-view.component.html',
  styleUrls: ['./order-view.component.scss']
})
export class OrderViewComponent implements OnInit {

  orderDataList: any[] = [];
  constructor(private route: ActivatedRoute,public orderManagementService : OrderManagementService,public messageService: MessageService) { }

  ngOnInit(): void {
    this.fetchOrderDetails();
  }

  //function fetch the particular order details by cart id

  fetchOrderItemsById() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.orderManagementService.getOrderedItemsList(id).subscribe((response) =>{
        if(response.data && response.data !== null){
            this.orderDataList = response.data;
        }
    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    });
 }

 fetchOrderDetails(){
  const id = Number(this.route.snapshot.paramMap.get('id'));

  this.orderManagementService.getOrderDetails(id).subscribe((response) =>{
    if(response.data && response.data !== null){
        this.orderManagementService.orderDetails = response.data;
        this.fetchOrderItemsById();    }
},
(error) => {
  this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
  console.log("error", error);
});
 }

}

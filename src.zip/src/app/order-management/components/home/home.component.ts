import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService, SelectItem } from 'primeng/api';
import { Item } from '../../model/item';
import { OrderManagementService } from '../../services/order-management.service';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  products: Item[];

  sortOptions: SelectItem[];

  sortOrder: number;

  sortField: string;

  isSpinner: boolean;

  itemCategoryList : SelectItem[] = [];

  itemListTemp:any [] = [];
  constructor(public orderManagementService: OrderManagementService, public storeService: StoreService, public messageService: MessageService) { }

  ngOnInit(): void {
    this.getAllProducts();

    this.sortOptions = [
      { label: 'Price High to Low', value: '!price' },
      { label: 'Price Low to High', value: 'price' }
    ];

    this.itemCategoryList = [
      { label: 'All', value: 'all' }
    ]

      this.orderManagementService.getCartItemsList();
  }

  //function for sort the items by price

  onSortChange(event) {
    this.isSpinner = true;

    let value = event.value;

    if (value.indexOf('!') === 0) {
      this.sortOrder = -1;
      this.sortField = value.substring(1, value.length);
    }
    else {
      this.sortOrder = 1;
      this.sortField = value;
    }
    this.isSpinner = false;

  }

  //function for get all list of items

  getAllProducts() {
    this.isSpinner = true;
    this.orderManagementService.getProducts().subscribe((response) => {
      if (response.status == 200 && response.data !== null) {
        this.products = response.data;
        this.itemListTemp = response.data;
        const unique_Category = [...new Set(this.products.map((result) => result.category))];
        unique_Category.forEach((item) => {
          this.itemCategoryList.push({ label: item, value: item.toLowerCase() });
        });        
      }
    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    });
    this.isSpinner = false;

  }

  //function for filter the item by category
  onCategoryChange(event){
    let filtered : any[] = [];
    let query = event.value;

    if (query != 'all') {
      for(let i = 0; i < this.itemListTemp.length; i++) {
        let item = this.itemListTemp[i];
        if (item.category.toLowerCase().indexOf(query.toLowerCase()) == 0) {
            filtered.push(item);
        }
    }
    this.products = filtered;
    } else {
      this.products = this.itemListTemp;
    }

    
  }

}

import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { OrderManagementService } from '../../services/order-management.service';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss']
})
export class OrderListComponent implements OnInit {

  
  orderedItemsList: any [] = [];
    
  constructor(public orderManagementService: OrderManagementService,public messageService: MessageService) { }

  ngOnInit() {
    this.getAllOrderList();
  }

  //function for fetch the allorderlist details
  
  getAllOrderList(){
    this.orderManagementService.getAllOrderList().subscribe((response)=>{
      if (response.data && response.data !== null) {
        this.orderedItemsList = response.data;
      }
    },
    (error) => {
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
      console.log("error", error);
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth/auth.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  userProfileDetails:any = {};

  constructor(public authService: AuthService) { }

  ngOnInit(): void {
    this.getProfileDetails();
  }

    //function fetch the particular userdetails by user id

  getProfileDetails(){
    this.authService.getUserDetailsByID().subscribe((response)=>{
      if (response.data && response.data !== null) {
        this.userProfileDetails = response.data;
        this.getUserDeliveryLocationDetails();
      }
    });
  }

    //function fetch the particular address details by user id

  getUserDeliveryLocationDetails(){
    this.authService.getUserDeleveryDetailsByID().subscribe((response)=>{
      if (response.data && response.data !== null) {
        this.userProfileDetails.deliveryDetails = response.data;
      }
    });
  }

}

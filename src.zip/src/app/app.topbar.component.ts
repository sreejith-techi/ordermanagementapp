import {Component} from '@angular/core';
import {AppMainComponent} from './app.main.component';
import { OrderManagementService } from './order-management/services/order-management.service';
import { AuthService } from './services/auth/auth.service';

@Component({
    selector: 'app-topbar',
    templateUrl: './app.topbar.component.html'
})
export class AppTopBarComponent {

    constructor(public appMain: AppMainComponent,public authService : AuthService,public orderManagementService: OrderManagementService) {

    }

    ngOnInit(){
        this.authService.userDetails = JSON.parse(localStorage.getItem('currentUser'));
    }


    logoutUser(){
        this.authService.logout();
    }
   
    
    

}

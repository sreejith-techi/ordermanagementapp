export const environment = {
    production: false,

    api_url:"https://localhost:7068/"  // stagging
   
    // api_url:"https://authstg.elifcs.com/"         // live
   

 
};


import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { AuthService } from 'src/app/services/auth/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  returnUrl: string;
  isSpinner: boolean = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService, private messageService: MessageService
  ) { }

  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }

  ngOnInit() {

    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.authService.logout();
  }

  //function for login the user

  loginUser() {

    this.authService.login(this.username.value, this.password.value).subscribe((response) => {
    if (response.token !== null && response.userID !== null) {
           this.authService.userDetails = response;         
          localStorage.setItem('currentUser', JSON.stringify(response));
          const redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/app/home';
          this.router.navigate([redirect]);
    }
  },
      (error) => {
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: error.message });
        console.log("error", error);
      }
    );

  }
}

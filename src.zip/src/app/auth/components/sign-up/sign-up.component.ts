import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { AuthService } from 'src/app/services/auth/auth.service';
import { HelperView } from 'src/app/shared/helper.view';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit {

  customerForm: any = {};
  displayMessage: boolean;
  userDetails: any = {};
  addressDetails: any = {};
  constructor(private router: Router, private authService: AuthService, private messageService: MessageService) { }

  ngOnInit(): void {
  }

// function for create new customer
  registerCustomer() {
    if (this.validationForSignUp()) {

        this.authService.signUp(this.customerForm).subscribe((data) => {
          if (data) {
            this.userDetails = data;
            this.addAdressLocation(data);
          }
         } ,
          (error) => {
            this.messageService.add({ severity: 'error', summary: 'Failed', detail: "Try again later" });
            console.log("error", error);
          }
        );
      
    }

  }

// function for add new customer address location

  addAdressLocation(data) {
    let payLoad = {
      "userID": data.userID,
      "fullName": data.userName,
      "mobileNumber": data.contactNo,
      "pinCode": this.addressDetails.pincode,
      "flatNo": this.addressDetails.flat,
      "area": this.addressDetails.area,
      "landMark": this.addressDetails.landMark,
      "city": data.city
    }
    try {
      this.authService.addAddressLocation(payLoad).subscribe((data) => {
        if (data) {
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Customer Registered Successfully' });
          setTimeout(() => {
            this.showBasicDialog();
          }, 500);
        }
      });
    } catch (error) {
      console.log('error', error)
    }
  }

// function for show the login deatils in dialog box 
  
  showBasicDialog() {
    this.displayMessage = true;
  }

  // function for validating  customer registertion form

  validationForSignUp() {

    if (!HelperView.checkStringEmptyOrNull(this.customerForm.userName)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Name is required' });
      return false;
    } else if (!HelperView.isValidNumber(this.customerForm.contactNo)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Enter Valid Phone Number' });
      return false;
    } else if (!HelperView.isValidMailFormat(this.customerForm.email)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Enter Valid Email' });
      return false;
    } else if (!HelperView.checkStringEmptyOrNull(this.customerForm.country)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Country is required' });
      return false;
    } else if (!HelperView.checkStringEmptyOrNull(this.customerForm.state)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'State is required' });
      return false;
    } else if (!HelperView.checkStringEmptyOrNull(this.customerForm.district)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'District is required' });
      return false;
    } else if (!HelperView.checkStringEmptyOrNull(this.customerForm.city)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'City is required' });
      return false;
    } else if (!HelperView.checkStringEmptyOrNull(this.addressDetails.landMark)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Landmark is required' });
      return false;
     }  else if (!HelperView.checkStringEmptyOrNull(this.addressDetails.area)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Area is required' });
      return false;
     }  else if (!HelperView.checkStringEmptyOrNull(this.addressDetails.flat)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Flat is required' });
      return false;
     } else if (!HelperView.checkStringEmptyOrNull(this.addressDetails.pincode)) {
      this.messageService.add({ severity: 'warn', summary: 'Warning', detail: 'Pincode is required' });
      return false;
     } else {
      return true;
    }
  }


}
